<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Index</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <style>
    th,
    td {
      padding: 10px;
    }
  </style>
</head>

<body>
  <!-- Button tdigger modal -->
  <button style="
  float: right;
  margin-top: -4rem;
  margin-right: 10rem;
" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
    create
  </button>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="tdue">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Data</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="tdue">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form id="newModalForm" class="form" role="form">
            <div class="form-group">
              <label for="exampleInputEmail1">Name</label>
              <input type="text" id="name" class="form-control" placeholder="Enter name" required="required">
              <!-- <small id="emailHelp" class="form-text text-muted"></small> -->

            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Email</label>
              <input type="email" id="email" class="form-control" placeholder="Enter email" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Phone</label>
              <input type="text" class="form-control" id="phone" placeholder="enter number" required="required">
            </div>
            <select id="country" class="custom-select" required="required">
              <option disabled selected>Select-Country</option>
              <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countrys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($countrys->id); ?>"><?php echo e($countrys->country); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <select id="state" class="custom-select">
              <option disabled selected>Select-State</option>

            </select><br><br>
            <select id="city" class="custom-select">
              <option disabled selected>Select-City</option>
            </select><br><br>
            <label for="exampleInputPassword1">Gender</label>
            <div class="form-check">
              <input class="form-check-input gender" type="radio" name="exampleRadios" id="exampleRadios1" value="0" required="required">
              <label class="form-check-label" for="exampleRadios1">
                Male
              </label>
            </div>

            <div class="form-check">
              <input class="form-check-input gender" type="radio" name="exampleRadios" id="exampleRadios1" value="1">
              <label class="form-check-label" for="exampleRadios1">
                Female
              </label>
            </div><br>
            <select id="education" class="custom-select">
              <option disabled selected>Select-Education</option>
              <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($study->education); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <div class="form-group">
              <label for="exampleInputPassword1">password</label>
              <input type="password" class="form-control" id="password" placeholder="Enter Password" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">confirm password</label>
              <input type="password" class="form-control" id="confirmation_password" placeholder=" Enter Password" required="required">
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-danger reset">Reset</button>
              <a href="javascript:void(0)" id="save" class="btn btn-primary">Save changes</a>
            </div>
          </form>
        </div>

      </div>
    </div>

  </div>


<!-- ***************************************************************************************************************************************************** -->
<!-- ***************************************************************************************************************************************************** -->

  <!-- Model 2  -->
  <div class="modal fade" id="myModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="tdue">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="tdue">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form id="newModalForm" class="form2" role="form">
            <div class="form-group">
              <label for="exampleInputEmail1">Name</label>
              <input type="text" id="name_edit" class="form-control" placeholder="Enter name" required="required">
              <!-- <small id="emailHelp" class="form-text text-muted"></small> -->

            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Email</label>
              <input type="email" id="email_edit" class="form-control" placeholder="Enter email" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Phone</label>
              <input type="text" class="form-control" id="phone_edit" placeholder="enter number" required="required">
            </div>
            <select id="country_edit" class="custom-select" required="required">
              <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countrys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option  value="<?php echo e($countrys->id); ?>"><?php echo e($countrys->country); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <select id="state_edit" class="custom-select">
              <option disabled>Select-State</option>
              <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option  value="<?php echo e($states->id); ?>"><?php echo e($states->state); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <select id="city_edit" class="custom-select">
              <option disabled>Select-City</option>
              <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option  value="<?php echo e($cities->id); ?>"><?php echo e($cities->city); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <label for="exampleInputPassword1">Gender</label>
            <div id="editgender">
              <div class="form-check">
                <input class="form-check-input gender_edit" type="radio" name="gender" id="" value="0">
                <label class="form-check-label" for="exampleRadios1">
                  Male
                </label>
              </div>

              <div class="form-check">
                <input class="form-check-input gender_edit" type="radio" name="gender" id="" value="1">
                <label class="form-check-label" for="exampleRadios1">
                  Female
                </label>
              </div>
            </div><br>
            <select id="education_edit" class="custom-select">
              <option disabled selected>Select-Education</option>
              <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($study->education); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <div class="form-group">
              <label for="exampleInputPassword1">password</label>
              <input type="password" class="form-control" id="password_edit" placeholder="Enter Password" required="required">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-danger reset">Reset</button>
              <a href="javascript:void(0)" id="update" class="btn btn-primary">Save changes</a>
            </div>
          </form>
        </div>

      </div>
    </div>

  </div>




  <table style="margin-left: 10rem;
margin-top: 5rem;" border="1">
    <tr>
      <!-- <th>Id</th> -->
      <th>Name</th>
      <th>Email</th>
      <th>Phone</th>
      <!-- <th>Country</th>
      <th>State</th>
      <th>City</th> -->
      <th>Gender</th>
      <th>Education</th>
      <th>Password</th>
      <th>Action</th>
      <th>Action</th>
    </tr>
    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($row->name); ?></td>
      <td><?php echo e($row->email); ?></td>
      <td><?php echo e($row->phone); ?></td>
      <!-- <td><?php echo e($row->country); ?></td>
      <td><?php echo e($row->state); ?></td>
      <td><?php echo e($row->city); ?></td> -->
      <?php if($row->gender == '0'): ?>
      <td>male</td>
      <?php else: ?>
      <td>female</td>
      <?php endif; ?>
      <td><?php echo e($row->education); ?></td>
      <td><?php echo e($row->password); ?></td>
      <td><button class="btn btn-danger btn-sm del_row" data-id="<?php echo e($row->id); ?>" id="del_row">Delete</button></td>
      <td><button class="btn btn-dark btn-sm edit_row" data-toggle="modal" data-target="#myModel" data-id="<?php echo e($row->id); ?>" id="edit_row">Edit</button></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>



  <!-- insert data  -->

  <script>
    $(document).ready(function() {

      $("#save").click(function() {

        var name = $('#name').val();
        var email = $('#email').val();
        var phone = $('#phone').val();
        var country = $('#country').val();
        var state = $('#state').val();
        var city = $('#city').val();
        var gender = $(".gender:checked").val();
        var education = $('#education').val();
        var password = $('#password').val();
        var confirmation_password = $('#confirmation_password').val();

        $.ajax({
          url: "<?php echo e(route('store')); ?>",
          type: "POST",
          data: {
            name: name,
            email: email,
            phone: phone,
            country: country,
            state: state,
            city: city,
            gender: gender,
            education: education,
            password: password,
            confirmation_password: confirmation_password,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function(data) {
            if (data == 'true') {

              alert('data successfully saved');
              $(".form")[0].reset();
              window.location.reload();

            } else {
              alert('please enter correct details');
            }
          }
        });
      });



    });
  </script>

  <!-- delete data  -->

  <script>
    $(document).ready(function() {
      $('.del_row').on('click', function() {

        var id = $(this).data('id');

        if (confirm('are you sure want to delete')) {

          $.ajax({
            type: "POST",
            url: "<?php echo e(route('delete')); ?>",
            data: {
              id: id,
              _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(data) {
              if (data == 'true') {
                alert('data deleted successfully');
                window.location.reload();
              } else {
                alert('data not deleted');
              }
            }
          });
        }

      });

    });
  </script>

    <!-- get edit view  -->

  <script>
    $(document).ready(function() {
      $('.edit_row').on('click', function() {

        var id = $(this).data('id');

        $.ajax({
          type: "POST",
          url: "<?php echo e(route('edit')); ?>",
          data: {
            id: id,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function(data) {
            console.log(data);
            $('#update').val(data.result.id);
            $('#name_edit').val(data.result.name);
            $('#email_edit').val(data.result.email);
            $('#phone_edit').val(data.result.phone);
            $('#country_edit').val(data.result.country);
            $('#state_edit').val(data.result.state);
            $('#city_edit').val(data.result.city);
            $('#education_edit').val(data.result.education);
            $('#password_edit').val(data.result.password);
            if (data.result.gender == '0') {
              $('#editgender').find(':radio[name=gender][value="0"]').prop('checked', true);
            } else {
              $('#editgender').find(':radio[name=gender][value="1"]').prop('checked', true);
            }
          }
        });

      });

    });

    $('.reset').click(function() {
      $('.form')[0].reset();
      $('.form2')[0].reset();
    });
  </script>

    <!-- country - state  -->

  <script>
    $(document).ready(function() {
      $('#country').on('change', function() {
        jQuery('#city').html('<option disabled selected>Select-City</option>');
        var id = $(this).val();

        $.ajax({
          type: "POST",
          url: "<?php echo e(route('country')); ?>",
          data: {
            id: id,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function(data) {
            jQuery('#state').html(data);
          }
        });

      });

    });
  </script>

    <!-- state - city  -->

  <script>
    $(document).ready(function() {
      $('#state').on('change', function() {

        var id = $(this).val();

        $.ajax({
          type: "POST",
          url: "<?php echo e(route('state')); ?>",
          data: {
            id: id,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function(data) {
            jQuery('#city').html(data);
          }
        });

      });

    });
  </script>

    <!-- update data  -->

  <script>
    $(document).ready(function() {

      $("#update").click(function() {
        var id = $('#update').val();
        var name = $('#name_edit').val();
        var email = $('#email_edit').val();
        var phone = $('#phone_edit').val();
        var country = $('#country_edit').val();
        var state = $('#state_edit').val();
        var city = $('#city_edit').val();
        var gender = $(".gender_edit:checked").val();
        var education = $('#education_edit').val();
        var password = $('#password_edit').val();

        $.ajax({
          url: "<?php echo e(route('update')); ?>",
          type: "POST",
          data: {
            id:id,
            name: name,
            email: email,
            phone: phone,
            country: country,
            state: state,
            city: city,
            gender: gender,
            education: education,
            password: password,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function(data) {
            if (data == 'true') {

              alert('data successfully updated');
              $(".form")[0].reset();
              window.location.reload();

            } else {
              alert('data not update');
            }
          }
        });
      });



    });
  </script>


    <!-- ******************************************************************************************************************* -->


    <!-- country - state Model-2 -->

  <script>
    $(document).ready(function() {
      $('#country_edit').on('change', function() {

        var id = $(this).val();
        jQuery('#city').html('<option disabled selected>Select-City</option>');

        $.ajax({
          type: "POST",
          url: "<?php echo e(route('country')); ?>",
          data: {
            id: id,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function(data) {
            jQuery('#state_edit').html(data);
          }
        });

      });

    });
  </script>

    <!-- state - city Model-2  -->

  <script>
    $(document).ready(function() {
      $('#state_edit').on('change', function() {

        var id = $(this).data('id');

        $.ajax({
          type: "POST",
          url: "<?php echo e(route('state')); ?>",
          data: {
            id: id,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function(data) {
            jQuery('#city_edit').html(data);
          }
        });

      });

    });
  </script>


</body>

</html><?php /**PATH C:\Users\ZTPL0113\Desktop\laravel_pratical\crud\resources\views/index.blade.php ENDPATH**/ ?>