<form id="newModalForm" role="form">
            <div class="form-group">
              <label for="exampleInputEmail1">Name</label>
              <input type="text" id="name" class="form-control" placeholder="Enter name" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Email</label>
              <input type="email" id="email" class="form-control" placeholder="Enter email" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Phone</label>
              <input type="text" class="form-control" id="phone" placeholder="enter number" required="required">
            </div>
            <select id="country" class="custom-select" required="required">
              <option disabled selected>Select-Country</option>
              @foreach($country as $countrys)
              <option>{{$countrys->country}}</option>
              @endforeach
            </select><br><br>
            <select id="state" class="custom-select">
              <option disabled selected>Select-State</option>
              @foreach($state as $states)
              <option>{{$states->state}}</option>
              @endforeach
            </select><br><br>
            <select id="city" class="custom-select">
              <option disabled selected>Select-City</option>
              @foreach($city as $cities)
              <option>{{$cities->city}}</option>
              @endforeach
            </select><br><br>
            <label for="exampleInputPassword1">Gender</label>
            <div class="form-check">
              <input class="form-check-input gender" type="radio" name="exampleRadios" id="exampleRadios1" value="0" required="required">
              <label class="form-check-label" for="exampleRadios1">
                Male
              </label>
            </div>

            <div class="form-check">
              <input class="form-check-input gender" type="radio" name="exampleRadios" id="exampleRadios1" value="1">
              <label class="form-check-label" for="exampleRadios1">
                Female
              </label>
            </div><br>
            <select class="custom-select">
              <option id="education" disabled selected>Select-Education</option>
              @foreach($education as $study)
              <option>{{$study->education}}</option>
              @endforeach
            </select><br><br>
            <div class="form-group">
              <label for="exampleInputPassword1">password</label>
              <input type="password" class="form-control" id="password" placeholder="Enter Password" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">confirm password</label>
              <input type="password" class="form-control" id="confirmation_password" placeholder=" Enter Password" required="required">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" id="save" class="btn btn-primary">Save changes</button>
            </div>
          </form>