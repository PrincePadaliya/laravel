<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {

        $data['result'] = DB::table('info')
            ->leftjoin('country', 'info.country', '=', 'country.id')
            ->leftjoin('state', 'info.state', '=', 'state.id')
            ->leftjoin('city', 'info.city', '=', 'city.id')
            ->orderBy('id', 'asc')
            ->get(array('info.*','country.country','state.state','city.city'));

        $data['country'] = DB::table('country')->orderBy('country', 'asc')->get();

        $data['education'] = DB::table('education')->orderBy('education', 'asc')->get();

        // echo '<pre>';
        // print_r($data);die;

        return view('index', $data);
    }

    public function store(Request $request)
    {
        $input = $request->all();

        if ($input['password'] == $input['confirmation_password']) {

            if(!empty($input['education'])){
                $education = implode(",", $input['education']);
            }else{
                $education = '';
            }

            $data = array(
                "name" => $input['name'],
                "email" => $input['email'],
                "phone" => $input['phone'],
                "country" => $input['country'],
                "state" => $input['state'],
                "city" => $input['city'],
                "gender" => $input['gender'],
                "education" => $education,
                "password" => $input['password']
            );


            $insert = DB::table('info')->insertGetId($data);

            // for ($i = 0; $i < count($input['education']); $i++) {
            //     $newdata = array(
            //         "info_id" => $insert,
            //         "name" => $input['education'][$i],
            //     );
            //     DB::table('education_list')->insert($newdata);
            // }

            if ($insert) {
                echo 'true';
            } else {
                echo 'false';
            }
        } else {
            echo 'not';
        }
    }

    public function delete(Request $request)
    {
        $input = $request->all();

        $delete = DB::table('info')->where('id', $input['id'])->delete();

        echo 'true';
    }

    public function edit(Request $request)
    {
        $input = $request->all();
        
        $data['result'] = DB::table('info')->where('id', $input['id'])->first();
        $data['state'] = DB::table('state')->where('country_id', $data['result']->country)->get();
        $data['city'] = DB::table('city')->where('state_id', $data['result']->state)->get();
        
        $data['education'] = explode(",", $data['result']->education);
        $data['education_list'] = DB::table('education')->get('education');
        
        // $html = '<option value="">Select-State</option>';

        // foreach($list as $data){
        //     $html .= '<option value="'.$data->id.'">'.$data->city.'</option>';
        // }

        return response()->json($data);
    }

    public function update(Request $request)
    {
        $input = $request->all();

        if(!empty($input['education'])){
            $education = implode(",", $input['education']);
        }else{
            $education = '';
        }

        $data = array(
            "name" => $input['name'],
            "email" => $input['email'],
            "phone" => $input['phone'],
            "country" => $input['country'],
            "state" => $input['state'],
            "city" => $input['city'],
            "gender" => $input['gender'],
            "education" => $education,
            "password" => $input['password']
        );

        // $count_education = DB::table('education_list')->where("info_id", $input['id'])->get();

        // if(count($count_education) > 0){
        //     DB::table('education_list')->where("info_id", $input['id'])->delete();
        // }
        

        $update = DB::table('info')->where('id', $input['id'])->update($data);

        // for ($i = 0; $i < count($input['education']); $i++) {
        //     $newdata = array(
        //         "info_id" => $input['id'],
        //         "name" => $input['education'][$i],
        //     );
        //     DB::table('education_list')->insert($newdata);
        // }

        echo 'true';
        
    }
    

    public function country(Request $request)
    {
        $input = $request->all();

        $list = DB::table('state')->where('country_id', $input['id'])->orderBy('state', 'asc')->get();

        $html = '<option value="">Select-State</option>';

        foreach ($list as $data) {
            $html .= '<option value="' . $data->id . '">' . $data->state . '</option>';
        }

        echo $html;
        // return response()->json($data);
    }


    public function state(Request $request)
    {
        $input = $request->all();

        $list = DB::table('city')->where('state_id', $input['id'])->orderBy('city', 'asc')->get();

        $html = '<option value="">Select-State</option>';

        foreach ($list as $data) {
            $html .= '<option value="' . $data->id . '">' . $data->city . '</option>';
        }

        echo $html;
        // return response()->json($data);
    }
}
