<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(){
        $data['result'] = DB::table('info')->get();

        // echo '<pre>';
        // print_r($data);die;
        $data['country'] = DB::table('country')->orderBy('country','asc')->get();
        $data['state'] = DB::table('state')->get();
        $data['city'] = DB::table('city')->get();
        $data['education'] = DB::table('education')->get();

        

        return view('index', $data);
    }

    public function store(Request $request){
        $input = $request->all();
        
        // $request->validate([
        //     'name' => 'required|max:255',
        //     'email' => 'required|max:255',
        //     'phone' => 'required|max:255|min:10|max:10',
        //     'country' => 'required|max:255',
        //     'state' => 'required|max:255',
        //     'city' => 'required|max:255',
        //     'gender' => 'required|max:255',
        //     'education' => 'required|max:255',
        //     'password' => 'required|confirmed|min:6',
        // ]);

        if($input['password'] == $input['confirmation_password']){

        $data = array(
            "name" => $input['name'],
            "email" => $input['email'],
            "phone" => $input['phone'],
            "country" => $input['country'],
            "state" => $input['state'],
            "city" => $input['city'],
            "gender" => $input['gender'],
            "education" => $input['education'],
            "password" => $input['password']
        );
        

            $insert = DB::table('info')->insert($data);   
                if($insert){
                    echo 'true';
                }else{
                    echo 'false';
                }
        }else{
            echo 'not';
        }
    }

    public function delete(Request $request){
        $input = $request->all();
       
        $delete = DB::table('info')->where('id', $input['id'])->delete();
        
        echo 'true';
    }

    public function edit(Request $request){
        $input = $request->all();
        $data['result'] = DB::table('info')->where('id', $input['id'])->first();
        // $data['country'] = DB::table('country')->get();
        $data['state'] = DB::table('state')->where('country_id',$data['result']->country)->get();
        // echo '<pre>';
        // print_r($data['state']);die;
        $data['city'] = DB::table('city')->get();
        $data['education'] = DB::table('education')->get();
        
        // $html = '<option value="">Select-State</option>';

        // foreach($list as $data){
        //     $html .= '<option value="'.$data->id.'">'.$data->city.'</option>';
        // }
   
        return response()->json($data);
    }

    public function update(Request $request){
        $input = $request->all();

        $data = array(
            "name" => $input['name'],
            "email" => $input['email'],
            "phone" => $input['phone'],
            "country" => $input['country'],
            "state" => $input['state'],
            "city" => $input['city'],
            "gender" => $input['gender'],
            "education" => $input['education'],
            "password" => $input['password']
        );

        $update = DB::table('info')->where('id', $input['id'])->update($data);

        if($update){
            echo 'true';
        }else{
            echo 'false';
        }
    }

    public function country(Request $request){
        $input = $request->all();
        
        $list = DB::table('state')->where('country_id', $input['id'])->orderBy('state','asc')->get();

        $html = '<option value="">Select-State</option>';

        foreach($list as $data){
            $html .= '<option value="'.$data->id.'">'.$data->state.'</option>';
        }

        echo $html;
        // return response()->json($data);
    }


    public function state(Request $request){
        $input = $request->all();
        
        $list = DB::table('city')->where('state_id', $input['id'])->orderBy('city','asc')->get();

        $html = '<option value="">Select-State</option>';

        foreach($list as $data){
            $html .= '<option value="'.$data->id.'">'.$data->city.'</option>';
        }

        echo $html;
        // return response()->json($data);
    }
}
