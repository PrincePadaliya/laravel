<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <a href="<?php echo e(route('create')); ?>"><button>create</button></a>
    <a href="<?php echo e(route('logout')); ?>"><button>Logout</button></a>
    <h2> Hii <?php echo e(Auth::user()->name); ?></h2>
    <table border="1">
        <tr>
            <th>name</th>
            <th>email</th>
            <th>action</th>
            <th>action</th>
        </tr>

        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($row->name); ?></td>
            <td><?php echo e($row->email); ?></td>
            <td><a href="<?php echo e(route('edit', $row->id)); ?>"><button>edit</button></a></td>
            <td><a href="<?php echo e(route('delete', $row->id)); ?>"><button>delete</button></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <script type="text/javascript">
        function preventBack() {
            window.history.forward(); 
        }
          
        setTimeout("preventBack()", 0);
          
        window.onunload = function () { null };
    </script>
</body>

</html><?php /**PATH C:\Users\Asus\OneDrive\Desktop\test_laravel\laravel_crud\resources\views/index.blade.php ENDPATH**/ ?>