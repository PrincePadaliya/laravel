<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(route('store')); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" placeholder="name" name="name">
        <input type="email" placeholder="email" name="email">
        <button type="submit">submit</button>
        <a href="<?php echo e(route('index')); ?>">cancel</a>
    </form>
</body>
</html><?php /**PATH C:\Users\Asus\OneDrive\Desktop\test_laravel\laravel_crud\resources\views/create.blade.php ENDPATH**/ ?>