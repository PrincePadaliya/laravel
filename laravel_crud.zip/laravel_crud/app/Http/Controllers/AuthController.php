<?php

namespace App\Http\Controllers;
use DB;
use Auth;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class AuthController extends Controller
{
    public function login(){
        return view('login');
    }

    public function signin(Request $request){
        $input = $request->all();

        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);

        $credenctials = $request->only('email', 'password');
        if(Auth::attempt($credenctials)){
            return redirect()->route('index');
        }
        return redirect()->route('login')->withErrors('Login details are not valid');
    }

    public function register(){
        return view('register');
    }

    public function userstore(Request $request){

        $input = $request->all();

        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|confirmed',
            'phone' => 'required|min:10|max:10'
        ]);

        $data = array(
            "name" => $input['name'],
            "email" => $input['email'],
            "phone" => $input['phone'],
            "password" => Hash::make($input['password'])
        );

        DB::table('users')->insert($data);

        return redirect()->route('index');
    }

    public function logout(){
        Session::flush();
        Auth::logout();
        return redirect()->route('login');
    }
}
