<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;


class UserController extends Controller
{

    public function index(){
        $data['result'] = DB::table('info')->get();
        return view('index', $data);
    }

    public function create(){
        return view('create');
    }

    public function store(Request $request){
        $input = $request->all();

        $data = array(
            "name" => $input['name'],
            "email" => $input['email']
        );

        DB::table('info')->insert($data);

        return redirect()->route('index');

    }

    public function delete(Request $request, $id){
        DB::table('info')->where('id', $id)->delete();
        return redirect()->route('index');
    }

    public function edit($id){
        $data['result'] = DB::table('info')->where('id', $id)->first();

        return view('edit', $data);
    }

    public function update(Request $request, $id){
        $input = $request->all();

        $data = array(
            "name" => $input['name'],
            "email" => $input['email']
        );

        DB::table('info')->where('id', $id)->update($data);

        return redirect()->route('index');

    }
}
