<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <a href="{{route('create')}}"><button>create</button></a>
    <a href="{{route('logout')}}"><button>Logout</button></a>
    <h2> Hii {{Auth::user()->name}}</h2>
    <table border="1">
        <tr>
            <th>name</th>
            <th>email</th>
            <th>action</th>
            <th>action</th>
        </tr>

        @foreach($result as $row)
        <tr>
            <td>{{$row->name}}</td>
            <td>{{$row->email}}</td>
            <td><a href="{{route('edit', $row->id)}}"><button>edit</button></a></td>
            <td><a href="{{route('delete', $row->id)}}"><button>delete</button></a></td>
        </tr>
        @endforeach
    </table>
    <script type="text/javascript">
        function preventBack() {
            window.history.forward(); 
        }
          
        setTimeout("preventBack()", 0);
          
        window.onunload = function () { null };
    </script>
</body>

</html>